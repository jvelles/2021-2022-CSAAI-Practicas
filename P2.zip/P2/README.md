 # Práctica 2
En esta calculadora tenemos las siguientes funciones:
    - Suma
    - Resta
    - Producto
    - Division
    - Elevar un número
    - Raiz cuadrada
    - Número pi

También he implementado poder tanto como eliminar todos los numeros del display como poder eliminar el ultimo digito/operador introducido.
Cumple con todos los requisitos pedidos, como el de que solo se permitan operar dos digitos: OP1 - OPERATOR - OP2. Tampoco es posible introducir
dos simbolos seguidos.
Con todo esto, he intentado programar como mejor he podido la calculadora!
